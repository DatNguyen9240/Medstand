/**
 * GOOGLE SHEETS SYNC SYSTEM
 * Tệp: Code.gs
 * Chức năng: Kết nối máy chủ, lấy dữ liệu, kẻ viền và định dạng bảng tính tự động.
 */

// Tạo Menu khi mở file Google Sheets
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('Data Sync Hub')
    .addItem('Mở Bảng Điều Khiển', 'showSidebar')
    .addToUi();
}

// Mở bảng điều khiển bên phải màn hình
function showSidebar() {
  var html = HtmlService.createTemplateFromFile('Sidebar')
    .evaluate()
    .setTitle('Data Sync Hub')
    .setWidth(300);
  SpreadsheetApp.getUi().showSidebar(html);
}

// Đọc cấu hình đã lưu trước đó để tự động điền vào các ô nhập liệu
function getSavedConfig() {
  var userProperties = PropertiesService.getUserProperties();
  return {
    domain: userProperties.getProperty('sync_domain') || '',
    apiKey: userProperties.getProperty('sync_apikey') || '',
    username: userProperties.getProperty('sync_username') || 'admin'
  };
}

// Lưu lại thông tin cấu hình để lần sau không cần gõ lại
function saveConfig(domain, apiKey, username) {
  var userProperties = PropertiesService.getUserProperties();
  userProperties.setProperty('sync_domain', domain);
  userProperties.setProperty('sync_apikey', apiKey);
  userProperties.setProperty('sync_username', username);
}

// Hàm xử lý đồng bộ dữ liệu chính
function syncData(config) {
  var domain = config.domain.trim();
  var apiKey = config.apiKey.trim();
  var username = config.username.trim();
  var report = config.report;
  var isAppend = config.isAppend;
  
  // Lưu lại cấu hình để tự điền ở các lần sau
  saveConfig(domain, apiKey, username);
  
  var apiCode = report;
  var extraParams = {};
  
  // Phân loại các tham số lọc gửi lên máy chủ
  if (report === '@danh_muc-khachhang') {
    apiCode = '@danh_muc';
    extraParams['Type'] = 'khachhang';
    extraParams['timkiem'] = config.catalogSearch || '';
  } else if (report === '@danh_muc-sanpham') {
    apiCode = '@danh_muc';
    extraParams['Type'] = 'sanpham';
    extraParams['timkiem'] = config.catalogSearch || '';
  } else if (report === '@doanh_so') {
    extraParams['LoaiBaoCao'] = config.salesReportType || 'KhachHang';
    extraParams['TuNgay'] = config.salesFromDate || '';
    extraParams['DenNgay'] = config.salesToDate || '';
  } else if (report === '@tuyen_ban_hang') {
    extraParams['MaKhachHang'] = config.routesCustomer || '';
    extraParams['SoNgayVangMat'] = config.routesDays || 45;
    extraParams['NgayBaoDong'] = config.routesWarning || 7;
  }
  
  var sqlParams = {
    'ApiCode': apiCode,
    'apiKey': apiKey,
    'Username': username,
    'TopN': config.topn || 100
  };
  
  for (var key in extraParams) {
    sqlParams[key] = extraParams[key];
  }
  
  // Tạo đường dẫn API kèm bộ lọc ngày tháng
  var queryString = Object.keys(sqlParams).map(function(k) {
    return encodeURIComponent(k) + '=' + encodeURIComponent(sqlParams[k]);
  }).join('&');
  
  var fullUrl = domain + '/api/sheet-data?' + queryString;
  
  try {
    // Kết nối đến máy chủ lấy dữ liệu
    var response = UrlFetchApp.fetch(fullUrl, {
      'headers': {
        'Bypass-Tunnel-Reminder': 'true',
        'x-api-key': apiKey
      },
      'muteHttpExceptions': true
    });
    
    var responseCode = response.getResponseCode();
    var responseText = response.getContentText();
    
    if (responseCode !== 200) {
      var errorMsg = 'Lỗi kết nối (' + responseCode + ')';
      try {
        var errObj = JSON.parse(responseText);
        errorMsg = errObj.error || errObj.details || responseText;
      } catch(e) {}
      throw new Error(errorMsg);
    }
    
    var data = JSON.parse(responseText);
    
    if (!data || !Array.isArray(data)) {
      throw new Error('Định dạng dữ liệu trả về không đúng.');
    }
    
    if (data.length === 0) {
      return { success: true, rowCount: 0, message: 'Đồng bộ xong. Không tìm thấy dữ liệu nào khớp với điều kiện lọc.' };
    }
    
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var keys = Object.keys(data[0]);
    var startRow = 1;
    
    if (isAppend) {
      var lastRow = sheet.getLastRow();
      if (lastRow > 0) {
        // Chèn thêm 2 dòng trống ngăn cách đợt đồng bộ cũ và mới
        startRow = lastRow + 3;
      }
    } else {
      // Chế độ ghi đè: xóa sạch bảng tính hiện tại trước khi ghi mới
      sheet.clearContents();
      sheet.clearFormats();
    }
    
    var rowsToWrite = [];
    rowsToWrite.push(keys); // Ghi dòng tiêu đề
    
    for (var i = 0; i < data.length; i++) {
      var item = data[i];
      var row = keys.map(function(k) {
        var val = item[k];
        return (val === null || val === undefined) ? '' : val;
      });
      rowsToWrite.push(row);
    }
    
    // Ghi dữ liệu xuống các ô tính
    var range = sheet.getRange(startRow, 1, rowsToWrite.length, keys.length);
    range.setValues(rowsToWrite);
    
    // ĐỊNH DẠNG TRANG TRÍ BẢNG TÍNH TỰ ĐỘNG
    // 1. Tô màu nền tiêu đề cột màu xám Slate đậm, chữ trắng, in đậm
    var headerRange = sheet.getRange(startRow, 1, 1, keys.length);
    headerRange.setBackground('#334155')
               .setFontColor('#ffffff')
               .setFontWeight('bold')
               .setHorizontalAlignment('center')
               .setVerticalAlignment('middle');
    
    // 2. Kẻ đường viền lưới mảnh màu xám nhạt cho toàn bộ bảng dữ liệu mới
    var borderRange = sheet.getRange(startRow, 1, rowsToWrite.length, keys.length);
    borderRange.setBorder(true, true, true, true, true, true, '#cbd5e1', SpreadsheetApp.BorderStyle.SOLID);
    
    // 3. Tự giãn chiều rộng các cột cho vừa khít với chữ
    sheet.autoResizeColumns(1, keys.length);
    
    return {
      success: true,
      rowCount: data.length,
      message: 'Đồng bộ thành công ' + data.length + ' dòng dữ liệu (từ dòng ' + startRow + ' đến dòng ' + (startRow + rowsToWrite.length - 1) + ').'
    };
    
  } catch(error) {
    return {
      success: false,
      message: 'Đồng bộ thất bại: ' + error.message
    };
  }
}
