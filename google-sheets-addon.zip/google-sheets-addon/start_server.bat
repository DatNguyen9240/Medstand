@echo off
set "CURRENT_DIR=%~dp0"
if "%CURRENT_DIR:~-1%"=="\" set "CURRENT_DIR=%CURRENT_DIR:~0,-1%"

:: Tu dong do tim thu muc goc cua Server (co chua server.js)
if exist "%CURRENT_DIR%\server.js" (
    set "BASE_DIR=%CURRENT_DIR%"
) else if exist "%CURRENT_DIR%\..\server.js" (
    set "BASE_DIR=%CURRENT_DIR%\.."
) else (
    set "BASE_DIR=%CURRENT_DIR%"
)

echo =======================================================
echo            API PROXY SERVER STARTUP                    
echo =======================================================

set "NODE_EXE=%BASE_DIR%\n8n-system\.bin\node-v22.14.0-win-x64\node.exe"

:: 1. Xac dinh bo chay Node.js
if exist "%NODE_EXE%" (
    set "RUN_NODE=%NODE_EXE%"
    echo [INFO] Phat hien Node.js Portable tu n8n-system
    goto START_PROCESS
)

where node >nul 2>nul
if %errorlevel% equ 0 (
    set "RUN_NODE=node"
    echo [INFO] Su dung Node.js he thong (Global)
    goto START_PROCESS
)

echo.
echo [ERROR] Khong tim thay Node.js!
echo Vui long chay file n8n-system\start_n8n.bat truoc de tai Node.js ve local.
echo.
pause
exit /b 1

:START_PROCESS
:: 2. Tu dong dong goi tai nguyen moi nhat (Rebuild JS/CSS Bundle)
echo.
echo [1/3] Dang tu dong dong goi va toi uu hoa hieu nang...
if exist "%BASE_DIR%\scripts\build.js" (
    "%RUN_NODE%" "%BASE_DIR%\scripts\build.js"
    if %errorlevel% neq 0 (
        echo.
        echo [ERROR] Dong goi that bai! Vui long kiem tra lai code.
        echo.
        pause
        exit /b 1
    )
    echo [OK] Dong goi tai nguyen thanh cong.
) else (
    echo [INFO] Bo qua buoc dong goi tai nguyen (Khong co script build.js).
)

:: 3. Tu dong don dep tien trinh cu tren cong 3000 (Tranh loi trung cong)
echo.
echo [2/3] Dang kiem tra va giai phong cong 3000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
    echo [INFO] Phat hien Express Server cu voi PID %%a dang chiem cong 3000. Dang dong...
    taskkill /f /pid %%a >nul 2>&1
)
echo [OK] Cong 3000 da san sang.

:: 4. Khoi chay Express Server bao mat
echo.
echo [3/3] Dang khoi chay Express Server moi...
echo =======================================================
echo.
"%RUN_NODE%" "%BASE_DIR%\server.js"
